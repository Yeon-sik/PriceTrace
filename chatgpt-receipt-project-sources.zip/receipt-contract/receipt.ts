import { z } from "zod";
import type { PurchaseType, Receipt } from "./types";

const minorAmount = z.number().int();
const nonNegativeMinorAmount = minorAmount.nonnegative();
const identifierSchema = z.object({ scheme: z.string().min(1), value: z.string().min(1) });
const lineTypeSchema = z.enum(["product", "service", "discount", "fee", "tax", "tip", "refund", "rounding", "other"]);
const foodServiceLineSchema = z.object({
  /** A separately priced restaurant item; its amount is never folded into its parent. */
  role: z.enum(["main", "option", "side"]),
  /** Source line ID of the exact main menu only when the receipt makes it unambiguous. */
  applies_to_line_id: z.string().min(1).nullable(),
}).strict();
export const ReceiptFulfillmentTypeSchema = z.enum(["delivery", "takeout", "dine_in", "unknown"]);
export const ReceiptFulfillmentEvidenceSchema = z.enum(["printed", "user_confirmed", "unknown"]);

/**
 * Canonical, business-agnostic source-document contract. Money is always
 * expressed in currency minor units: 1200 KRW is `1200`, regardless of
 * presentation text. A source fact that is not printed or cannot be read is
 * null; PriceTrace's product projection applies stricter requirements.
 */
export const ReceiptJsonSchema = z.object({
  schema_version: z.literal("receipt.v2"),
  document: z.object({
    id: z.string().min(1).nullable(),
    type: z.enum(["receipt", "invoice", "order_confirmation", "credit_note", "statement", "voucher", "other"]),
    status: z.enum(["draft", "final", "voided", "refunded", "unknown"]),
    issued_on: z.string().date().nullable(),
    issued_at: z.string().datetime({ offset: true }).nullable(),
    currency: z.string().regex(/^[A-Z]{3}$/).nullable(),
    fulfillment: z.object({
      type: ReceiptFulfillmentTypeSchema,
      evidence: ReceiptFulfillmentEvidenceSchema,
    }).default({ type: "unknown", evidence: "unknown" }),
    source: z.object({
      capture_method: z.enum(["pos_export", "e_receipt", "ocr", "manual_transcription", "manual_entry", "unknown"]),
      original_document_id: z.string().min(1).nullable(),
      source_images: z.array(z.string().min(1)),
      transcription_status: z.enum(["unprocessed", "parsed", "verified", "user_verified", "unknown"]),
      notes: z.array(z.string()),
      raw_text: z.string().nullable().default(null),
    }),
  }),
  merchant: z.object({
    /** The seller, issuer, provider, or payee printed on the source document. */
    name: z.string().min(1).nullable(),
    branch_name: z.string().min(1).nullable(),
    business_kind: z.enum(["retail", "food_service", "transport", "accommodation", "healthcare", "professional_service", "utility", "government", "financial", "marketplace", "other", "unknown"]).default("unknown"),
    retail_channel: z.enum(["px", "regular", "unknown"]).default("unknown"),
    /** Shared product-code catalog, only when the merchant explicitly confirms it. */
    catalog_namespace: z.string().trim().min(1).nullable().default(null),
    merchant_id: z.string().min(1).nullable(),
    business_registration_number: z.string().min(1).nullable(),
    address: z.string().min(1).nullable(),
    phone: z.string().min(1).nullable(),
  }),
  line_items: z.array(z.object({
    id: z.string().min(1),
    type: lineTypeSchema,
    description: z.string().min(1).nullable(),
    source_line_references: z.array(z.string().min(1)),
    identifiers: z.array(identifierSchema),
    quantity: z.object({ value: z.number().positive(), unit: z.string().min(1) }).nullable(),
    unit_price_amount_minor: nonNegativeMinorAmount.nullable(),
    gross_amount_minor: nonNegativeMinorAmount.nullable(),
    discount_amount_minor: nonNegativeMinorAmount.nullable(),
    tax_amount_minor: nonNegativeMinorAmount.nullable(),
    net_amount_minor: minorAmount.nullable(),
    confidence: z.enum(["high", "medium", "low", "user_verified"]),
    tax_rate_percent: z.number().min(0).nullable(),
    food_service: foodServiceLineSchema.nullable().default(null),
  })),
  totals: z.object({
    items_gross_amount_minor: nonNegativeMinorAmount.nullable(),
    discount_amount_minor: nonNegativeMinorAmount.nullable(),
    tax_amount_minor: nonNegativeMinorAmount.nullable(),
    fee_amount_minor: minorAmount.nullable(),
    tip_amount_minor: minorAmount.nullable(),
    rounding_amount_minor: minorAmount.nullable(),
    grand_total_amount_minor: minorAmount.nullable(),
  }),
  payments: z.array(z.object({
    method: z.enum(["cash", "card", "bank_transfer", "mobile_payment", "gift_card", "points", "mixed", "unknown"]),
    amount_minor: minorAmount.nullable(),
    status: z.enum(["authorized", "paid", "refunded", "voided", "unknown"]),
    reference: z.string().min(1).nullable(),
  })),
}).superRefine((receipt, context) => {
  const linesById = new Map(receipt.line_items.map((line) => [line.id, line]));
  for (const [index, line] of receipt.line_items.entries()) {
    const foodService = line.food_service;
    if (foodService === null) continue;
    if (receipt.merchant.business_kind !== "food_service") {
      context.addIssue({ code: z.ZodIssueCode.custom, path: ["line_items", index, "food_service"], message: "식당 메뉴 역할은 food_service 영수증에만 기록할 수 있습니다." });
    }
    if (line.type !== "product") {
      context.addIssue({ code: z.ZodIssueCode.custom, path: ["line_items", index, "food_service"], message: "식당 메뉴 역할은 product 행에만 기록할 수 있습니다." });
    }
    if (foodService.role !== "option" && foodService.applies_to_line_id !== null) {
      context.addIssue({ code: z.ZodIssueCode.custom, path: ["line_items", index, "food_service", "applies_to_line_id"], message: "부모 메뉴 연결은 option 행에만 기록할 수 있습니다." });
    }
    if (foodService.applies_to_line_id !== null) {
      const parent = linesById.get(foodService.applies_to_line_id);
      if (!parent || parent.id === line.id || parent.food_service?.role !== "main") {
        context.addIssue({ code: z.ZodIssueCode.custom, path: ["line_items", index, "food_service", "applies_to_line_id"], message: "옵션은 같은 영수증의 main 메뉴 행 하나에만 연결할 수 있습니다." });
      }
    }
  }
});
export type ReceiptJson = z.infer<typeof ReceiptJsonSchema>;

export const receiptItemId = (receiptId: string, lineId: string) => `${receiptId}:${lineId}`;

export function purchaseTypeForReceipt(receipt: Pick<Receipt, "storeBusinessKind">): PurchaseType {
  return receipt.storeBusinessKind === "food_service" ? "menu_item" : "retail_product";
}

export function nullableSourceProductCode(sourceProductCode: string) {
  return sourceProductCode.trim().length > 0 ? sourceProductCode : null;
}

function sourceProductCode(line: ReceiptJson["line_items"][number]) {
  return line.identifiers.find((identifier) => identifier.scheme === "merchant_sku")?.value ?? "";
}

export function mapReceipt(input: unknown): Receipt {
  const data = ReceiptJsonSchema.parse(input);
  if (data.document.currency !== "KRW") throw new Error("현재 정산 화면은 KRW 영수증만 지원합니다.");
  if (data.merchant.name === null) throw new Error("현재 정산 화면은 발행자 또는 판매처명이 있는 영수증만 지원합니다.");
  const purchasedAt = data.document.issued_at ?? data.document.issued_on;
  if (purchasedAt === null) throw new Error("현재 정산 화면은 발행일 또는 발행 시각이 있는 영수증만 지원합니다.");
  if (data.totals.grand_total_amount_minor === null) throw new Error("현재 정산 화면은 확정 총액이 있는 영수증만 지원합니다.");
  const receiptId = data.document.id ?? `${data.merchant.name}:${purchasedAt}:${data.document.source.original_document_id ?? "unknown"}`;
  const items = data.line_items.flatMap((line) => {
    if (line.type !== "product" || line.description === null || line.quantity?.unit !== "each" || !Number.isInteger(line.quantity.value) || line.quantity.value <= 0 || line.net_amount_minor === null || line.net_amount_minor < 0 || line.net_amount_minor % line.quantity.value !== 0) return [];
    return [{ id: receiptItemId(receiptId, line.id), receiptId, sourceLineReferences: line.source_line_references, productName: line.description, sourceProductCode: sourceProductCode(line), unitPriceKrw: line.net_amount_minor / line.quantity.value, quantityValue: line.quantity.value, totalPriceKrw: line.net_amount_minor, confidence: line.confidence, foodServiceRole: line.food_service?.role, optionParentReceiptItemId: line.food_service?.applies_to_line_id ? receiptItemId(receiptId, line.food_service.applies_to_line_id) : null }];
  });
  const receipt = {
    id: receiptId,
    storeName: data.merchant.name,
    storeBranchName: data.merchant.branch_name,
    storeLabel: data.merchant.branch_name ? `${data.merchant.name} ${data.merchant.branch_name}` : data.merchant.name,
    storeBusinessKind: data.merchant.business_kind,
    storeMerchantId: data.merchant.merchant_id,
    storeBusinessRegistrationNumber: data.merchant.business_registration_number,
    storeAddress: data.merchant.address,
    storePhone: data.merchant.phone,
    retailChannel: data.merchant.retail_channel,
    catalogNamespace: data.merchant.catalog_namespace,
    fulfillmentType: data.document.fulfillment.type,
    fulfillmentEvidence: data.document.fulfillment.evidence,
    purchasedAt,
    transactionNumber: data.document.source.original_document_id ?? "",
    currency: "KRW" as const,
    totalPriceKrw: data.totals.grand_total_amount_minor,
    items,
  };
  auditReceipt(receipt, data);
  return receipt;
}

export function auditReceipt(receipt: Receipt, source?: ReceiptJson) {
  if (source) {
    const hasCompleteLineBreakdown = source.line_items.every((line) => line.gross_amount_minor !== null && line.discount_amount_minor !== null && line.tax_amount_minor !== null);
    const hasCompleteTotals = Object.values(source.totals).every((amount) => amount !== null);
    if (hasCompleteLineBreakdown && hasCompleteTotals) {
      const gross = source.line_items.filter((line) => line.type === "product" || line.type === "service").reduce((sum, line) => sum + (line.gross_amount_minor ?? 0), 0);
      const discount = source.line_items.reduce((sum, line) => sum + (line.discount_amount_minor ?? 0), 0);
      const tax = source.line_items.reduce((sum, line) => sum + (line.tax_amount_minor ?? 0), 0);
      if (gross !== source.totals.items_gross_amount_minor || discount !== source.totals.discount_amount_minor || tax !== source.totals.tax_amount_minor) throw new Error("영수증 품목 집계가 totals와 일치하지 않습니다.");
      const expected = source.totals.items_gross_amount_minor - source.totals.discount_amount_minor + source.totals.tax_amount_minor + source.totals.fee_amount_minor! + source.totals.tip_amount_minor! + source.totals.rounding_amount_minor!;
      if (expected !== source.totals.grand_total_amount_minor) throw new Error("영수증 총액 무결성 검증에 실패했습니다.");
    }
  }
  if (receipt.items.some((item) => item.unitPriceKrw * item.quantityValue !== item.totalPriceKrw)) throw new Error("배분 가능한 품목의 단가와 수량이 일치하지 않습니다.");
  const references = receipt.items.flatMap((item) => item.sourceLineReferences);
  if (new Set(references).size !== references.length) throw new Error("원본 품목 참조가 중복되었습니다.");
  return { itemCount: receipt.items.length, quantity: receipt.items.reduce((sum, item) => sum + item.quantityValue, 0), totalKrw: receipt.totalPriceKrw, sourceLineReferenceCount: references.length };
}
