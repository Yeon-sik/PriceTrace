# PriceTrace 영수증 입력 프로젝트 목표

## 목적

이 ChatGPT 프로젝트는 마트와 식당 영수증 사진을 **PriceTrace의 `receipt.v2` 초안 JSON**으로 옮기는 전용 작업공간이다.

결과물은 `private-data/receipt_YYYY-MM-DD_NNN.json`에 저장하기 전의 구조화 초안이다. 영수증 원본 사진은 로컬에 보존하고, ChatGPT는 사진에서 실제로 읽을 수 있는 사실만 반환한다.

## 성공 기준

- 마트 영수증은 판매처, 일자, 영수증 상품명, 인쇄된 판매처 상품코드, 수량, 금액, 할인/세금/수수료, 총액을 분리해 반환한다.
- 식당 영수증은 판매처, 일자, 메뉴명, 수량, 금액, 할인/세금/봉사료, 총액을 분리해 반환한다.
- 식당 영수증에 이용 방식이 직접 인쇄됐거나 사용자가 명시하면 `document.fulfillment`에 배달·포장·매장과 근거를 기록한다. 확인되지 않으면 `unknown`으로 둔다.
- 저장 가능한 결과는 `src/domain/receipt.ts`의 `ReceiptJsonSchema`와 `scripts/validate-private-receipts.ts`의 검증 규칙을 만족한다.
- 화면에 없는 정보는 `null` 또는 빈 배열로 유지한다. 추측으로 채우지 않는다.

## 절대 규칙

1. 상품명만으로 표준 상품, 공식 판매채널 상품, 브랜드, 규격, 판매처 상품코드를 확정하거나 연결하지 않는다.
2. 할인·세금·수수료·봉사료·반올림·환불을 상품 행에 합치지 않는다.
3. 원본 행 순서를 `source_line_references`로 보존한다.
4. 카드번호, 승인번호, 주소, 전화번호, 사업자등록번호, 현금영수증 번호, 바코드 전체값, OCR 원문 전체 텍스트는 반환하지 않는다.
5. `transcription_status`는 사람 검토 전 항상 `parsed`다. `user_verified`를 출력하지 않는다.
6. `catalog_namespace`는 판매처의 공용 코드 체계가 검증된 경우 외에는 `null`이다.
7. 배달료, 포장 할인, 메뉴명만으로 배달·포장·매장을 추정하지 않는다. 영수증 직접 표기는 `printed`, 사용자의 명시는 `user_confirmed` 근거로만 기록한다.

## 저장 전 운영 절차

1. 이 프로젝트 채팅에 영수증 사진 한 장 또는 한 거래의 모든 페이지를 올린다.
2. `PROJECT_INSTRUCTIONS.md`에 따른 결과를 받는다.
3. 반환 JSON의 `document.source.source_images`에 로컬 원본 파일 경로 또는 식별자를 추가한다.
4. 새 파일을 `private-data/receipt_YYYY-MM-DD_NNN.json`으로 저장한다. 기존 원본을 덮어쓰지 않는다.
5. `npm.cmd run validate:private-receipts -- private-data/receipt_YYYY-MM-DD_NNN.json`을 실행한다.
6. 공개 투영이 필요한 경우에만 `npm.cmd run sync:public-receipts`, `npm.cmd run check:public-receipts`를 순서대로 실행한다.

## 재생성 규칙

이 폴더는 업로드용 스냅샷이다. 계약·템플릿·검증 규칙이 바뀌면 저장소 루트에서 다음을 실행해 ZIP을 다시 생성한다.

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\scripts\build-chatgpt-receipt-project-pack.ps1
```

Supabase migration 변경의 동기화 판단 규칙은 `supabase/CHATGPT_PROJECT_SOURCE_SYNC.md`를 따른다.
